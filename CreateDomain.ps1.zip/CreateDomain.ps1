﻿configuration CreateDomain
{
   param
   (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $Credential,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $SafeModePassword,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $DomainJoinPassword,

        [Int]$RetryCount=60,
        [Int]$RetryIntervalSec=60
    )

    Import-DscResource -ModuleName ActiveDirectoryDsc, NetworkingDsc, StorageDsc, PSDesiredStateConfiguration, ComputerManagementDsc

    $DomainSplit = $DomainName.Split(".")
    #Get DomainDN
    foreach($name in $domainsplit){
        $i = 0..($domainsplit.Count - 1) | Where-Object { $domainsplit[$_] -eq $name }
        If($i -eq 0){
            $DomainDN = $DomainDN+"DC="+$name
        } else {
            $DomainDN = $DomainDN+",DC="+$name
        }
    }

    $Interface=Get-NetAdapter|Where-Object Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)


    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ActionAfterReboot = "ContinueConfiguration"
        }

        WaitforDisk Disk1
        {
            DiskId = 1
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        Disk ADDataDisk {
            DiskId = 1
            DriveLetter = "F"
            DependsOn = "[WaitForDisk]Disk1"
        }

        DnsServerAddress DnsServerAddress
        {
            Address        = '127.0.0.1'
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
        }

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
            DependsOn = "[WindowsFeature]ADDSTools"
        }
        
        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADPowerShell"
        }

        WindowsFeature BitLockerPassVwr
        {
            Ensure = "Present"
            Name = "RSAT-Feature-Tools-BitLocker-BdeAducExt"
            DependsOn = "[WindowsFeature]ADAdminCenter"
        }

        PendingReboot RebootAfterFeatures
        {
            Name           = 'AfterFeatures'
        }

        ADDomain FirstDC
        {
            DomainName                    = $DomainName
            Credential                    = $Credential
            SafemodeAdministratorPassword = $SafeModePassword
            ForestMode                    = 'WinThreshold'
            DomainMode                    = 'WinThreshold'
            DatabasePath                  = "F:\NTDS"
            LogPath                       = "F:\Logs"
            SysvolPath                    = "F:\SYSVOL"
            DependsOn                     = @("[WindowsFeature]ADDSInstall", "[Disk]ADDataDisk")
        }

        PendingReboot RebootAfterDomain
        {
            Name           = 'AfterDomain'
        }

        Script SetDNSConfigs
        {
      	    SetScript = {
                Add-DnsServerForwarder -IPAddress 168.63.129.16
                Write-Verbose -Verbose "Setting DNS Forwarder"
                Set-DnsServerScavenging -ApplyOnAllZones -ScavengingState $true -ScavengingInterval 1.00:00:00
                Write-Verbose -Verbose "Setting DNS Scavenging"
                #Mark server for reboot
                $global:DSCMachineStatus = 1
            }
            GetScript =  { @{ Result = (Get-DnsServerScavenging).ScavengingState } }
            TestScript = { 
                If((Get-DnsServerScavenging).ScavengingState -eq $true){
                    Return $true
                } else {
                    Return $false
                } 
            }
            DependsOn = "[ADDomain]FirstDC"
        }

        PendingReboot RebootAfterDNSConfig
        {
            Name           = 'AfterDNSConfig'
        }
        
        ADOptionalFeature RecycleBin
        {
            FeatureName                       = "Recycle Bin Feature"
            EnterpriseAdministratorCredential = $Credential
            ForestFQDN                        = $DomainName
            DependsOn                         = "[ADDomain]FirstDC"
        }

        $BaseOrgUnits = @(
            "Admin",
            "Devices",
            "Groups",
            "Servers",
            "User Accounts"
        )

        $Sub1OrgUnits = @{
            "Accounts" = @{
                Path = "OU=Admin,$DomainDN"
            }
            "Groups" = @{
                Path = "OU=Admin,$DomainDN"
            }
            "Service Accounts" = @{
                Path = "OU=Admin,$DomainDN"
            }
            "Desktops" = @{
                Path = "OU=Devices,$DomainDN"
            }
            "Laptops" = @{
                Path = "OU=Devices,$DomainDN"
            }
            "Kiosks" = @{
                Path = "OU=Devices,$DomainDN"
            }
            "RD Session Hosts" = @{
                Path = "OU=Devices,$DomainDN"
            }
            "Contacts" = @{
                Path = "OU=Groups,$DomainDN"
            }
            "Distribution Groups" = @{
                Path = "OU=Groups,$DomainDN"
            }
            "Security Groups" = @{
                Path = "OU=Groups,$DomainDN"
            }
            "Enabled Users" = @{
                Path = "OU=User Accounts,$DomainDN"
            }
            "Disabled Users" = @{
                Path = "OU=User Accounts,$DomainDN"
            }
        }

        $Sub2OrgUnits = @{
            "ADM" = @{
                Path = "OU=RD Session Hosts,OU=Devices,$DomainDN"
            }
            "EVAL" = @{
                Path = "OU=RD Session Hosts,OU=Devices,$DomainDN"
            }
            "USR" = @{
                Path = "OU=RD Session Hosts,OU=Devices,$DomainDN"
            }
        }

        foreach ($ou in $BaseOrgUnits) {
            ADOrganizationalUnit "Base-$($ou)"
            {
                Name   = $ou
                Path   = $DomainDN
                Ensure = 'Present'
            }        
        }

        foreach ($ou in $Sub1OrgUnits.keys) {
            ADOrganizationalUnit "Sub1-$($ou)"
            {
                Name   = $ou
                Path   = "$($Sub1OrgUnits.$ou.Path)"
                Ensure = 'Present'
            }        
        }
        
        foreach ($ou in $Sub2OrgUnits.keys) {
            ADOrganizationalUnit "Sub2-$($ou)"
            {
                Name   = $ou
                Path   = "$($Sub2OrgUnits.$ou.Path)"
                Ensure = 'Present'
            }        
        }

        ADUser 'domainjoin'
        {
            Ensure              = 'Present'
            UserName            = 'domainjoin'
            Password            = $DomainJoinPassword
            PasswordNeverResets = $true
            PasswordNeverExpires= $true
            DomainName          = $DomainName
            Path                = "OU=Service Accounts,OU=Admin,$DomainDN"
            DependsOn           = "[ADDomain]FirstDC"
            Credential          = $Credential
        }

        ADGroup 'AddAccountOperators'
        {
            GroupName           = 'Account Operators'
            MembershipAttribute = 'SamAccountName'
            MembersToInclude    = 'domainjoin'
            Credential          = $Credential
        }
   }
}