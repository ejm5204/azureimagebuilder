﻿Configuration AnotherDomainController
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DNSServer,
        
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $Credential,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $SafeModePassword
    )

    Import-DscResource -ModuleName ActiveDirectoryDsc, NetworkingDsc, StorageDsc, PSDesiredStateConfiguration, ComputerManagementDsc
    
    $DomainSplit = $DomainName.Split(".")
    #Get DomainDN
    foreach($name in $domainsplit){
        $i = 0..($domainsplit.Count - 1) | Where-Object { $domainsplit[$_] -eq $name }
        If($i -eq 0){
            $DomainDN = $DomainDN+"DC="+$name
        } else {
            $DomainDN = $DomainDN+",DC="+$name
        }
    }

    $Interface=Get-NetAdapter|Where-Object Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ActionAfterReboot = "ContinueConfiguration" 
        }
        
        WaitforDisk Disk1
        {
            DiskId = 1
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        Disk ADDataDisk {
            DiskId = 1
            DriveLetter = "F"
            DependsOn = "[WaitForDisk]Disk1"
        }
        
        DnsServerAddress DnsServerAddress
        {
            Address        = $DNSServer
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }
        
        WindowsFeature 'InstallADDomainServicesFeature'
        {
            Ensure    = 'Present'
            Name      = 'AD-Domain-Services'
            DependsOn ="[DnsServerAddress]DnsServerAddress"
        }

        WindowsFeature 'ADDSTools'
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]InstallADDomainServicesFeature"
        }

        WindowsFeature 'ADPowerShell'
        {
            Ensure    = 'Present'
            Name      = 'RSAT-AD-PowerShell'
            DependsOn = '[WindowsFeature]InstallADDomainServicesFeature'
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADPowerShell"
        }

        WindowsFeature BitLockerPassVwr
        {
            Ensure = "Present"
            Name = "RSAT-Feature-Tools-BitLocker-BdeAducExt"
            DependsOn = "[WindowsFeature]ADAdminCenter"
        }

        PendingReboot RebootAfterFeatures
        {
            Name           = 'AfterFeatures'
        }

        WaitForADDomain 'WaitForestAvailability'
        {
            DomainName  = $DomainName
            Credential  = $Credential
            WaitTimeout = 3600
            DependsOn   = '[WindowsFeature]BitLockerPassVwr'
        }

        ADDomainController 'AdditionalDC'
        {
            DomainName                    = $DomainName
            Credential                    = $Credential
            SafeModeAdministratorPassword = $SafeModePassword
            DatabasePath                  = 'F:\NTDS'
            LogPath                       = 'F:\Logs'
            SysvolPath                    = 'F:\SYSVOL'
            InstallDns                    = $true
            IsGlobalCatalog               = $true
            DependsOn                     = '[WaitForADDomain]WaitForestAvailability'
        }

        PendingReboot RebootAfterDomain
        {
            Name           = 'AfterDomain'
        }

        Script SetDNSForwarder
        {
      	    SetScript = {
                Add-DnsServerForwarder -IPAddress 168.63.129.16
                Write-Verbose -Verbose "Setting DNS Forwarder"
                #Mark server for reboot
                $global:DSCMachineStatus = 1
            }
            GetScript =  { @{ Result = (Get-DnsServerForwarder).IPAddress } }
            TestScript = { 
                If((Get-DnsServerForwarder).IPAddress -eq "168.63.129.16"){
                    Return $true
                } else {
                    Return $false
                } 
            }
            DependsOn = "[ADDomainController]AdditionalDC"
        }
        
        PendingReboot RebootAfterDNS
        {
            Name           = 'AfterDNS'
        }

    }
}